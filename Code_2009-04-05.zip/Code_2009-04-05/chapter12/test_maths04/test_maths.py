def test_add():
    assert 1+1 == 2

def test_subtract():
    a = 3
    b = a + 1
    c = b-1
    assert b-a == c, "The value of b-a does not equal c"
