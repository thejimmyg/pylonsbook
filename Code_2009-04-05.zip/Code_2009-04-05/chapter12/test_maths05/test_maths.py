def test_add():
    assert 1+1 == 2

def test_subtract():
    a = 3
    print "a is %s"%a
    b = a + 1
    print "b is %s"%b
    c = b-1
    print "c is %s"%c
    assert b-a == c

