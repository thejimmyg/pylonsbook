import emphasize_helper
import doctest
doctest.testmod(emphasize_helper)

