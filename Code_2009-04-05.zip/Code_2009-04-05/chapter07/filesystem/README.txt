The code is in FileSystem/filesystem/model/__init__.py and the test is in
filesystem/tests/test_models.py. It can be run with these commands:

    $ cd FileSystem
    $ nosetests filesystem/tests/test_models.py

Compared to a normal Python project, this one also as an attachments directory
and an extra attachments option pointing to the attachments directory in the
config file.
 
